package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

public class HomePage {
    private final WebDriver driver;

    // Locators
    private final By logo = By.className("login_logo");
    private final By usernameInput = By.id("user-name");
    private final By passwordInput = By.id("password");
    private final By loginButton = By.id("login-button");
    private final By loginFooter = By.cssSelector(".login_footer");
    private final By acceptedUserPanel = By.className("login_credentials_wrap");
    private final By passwordInfo = By.className("login_password");
    private final By favicon = By.cssSelector("link[rel*='icon']");

    public HomePage(WebDriver driver) {
        this.driver = driver;
    }

    public String getTitle() {
        return driver.getTitle();
    }

    public boolean isLogoVisible() {
        return elementExists(logo);
    }

    public boolean isUsernameVisible() {
        return elementExists(usernameInput);
    }

    public boolean isPasswordVisible() {
        return elementExists(passwordInput);
    }

    public boolean isLoginButtonVisible() {
        return elementExists(loginButton);
    }

    public boolean isLoginButtonEnabled() {
        try {
            WebElement b = driver.findElement(loginButton);
            return b.isEnabled();
        } catch (Exception e) {
            return false;
        }
    }

    public String getLoginButtonText() {
        try {
            WebElement e = driver.findElement(loginButton);
            String v = e.getAttribute("value");
            if (v != null && !v.trim().isEmpty()) return v.trim();
            return e.getText().trim();
        } catch (Exception ex) {
            return "";
        }
    }

    public String getUsernamePlaceholder() {
        try {
            return driver.findElement(usernameInput).getAttribute("placeholder");
        } catch (Exception e) {
            return "";
        }
    }

    public String getPasswordPlaceholder() {
        try {
            return driver.findElement(passwordInput).getAttribute("placeholder");
        } catch (Exception e) {
            return "";
        }
    }

    public boolean isFooterVisible() {
        return elementExists(loginFooter);
    }

    public String getAcceptedUsernamesText() {
        try {
            return driver.findElement(acceptedUserPanel).getText();
        } catch (Exception e) {
            return "";
        }
    }

    public String getPasswordInfoText() {
        try {
            return driver.findElement(passwordInfo).getText();
        } catch (Exception e) {

            try {
                return driver.findElement(loginFooter).getText();
            } catch (Exception ex) {
                return "";
            }
        }
    }

    public boolean isFaviconPresent() {
        try {
            List<WebElement> icons = driver.findElements(favicon);
            return icons.size() > 0;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean elementExists(By by) {
        try {
            return driver.findElement(by).isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }
}
