package tests;
import Pages.HomePage;
import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class HomePageTests extends BaseTest {
    private HomePage home;

    @BeforeClass
    public void openPage() {
        openHome();           // from BaseTest
        home = new HomePage(driver);
    }

    @Test
    public void tc001_homepageLoads() {
        String url = driver.getCurrentUrl();
        Assert.assertTrue(url.contains("saucedemo.com"), "homepage URL should contain saucedemo.com");
    }

    @Test
    public void tc002_logoDisplayed() {
        Assert.assertTrue(home.isLogoVisible(), "logo should be visible");
    }

    @Test
    public void tc003_titleCorrect() {
        Assert.assertEquals(home.getTitle(), "Swag Labs", "page title mismatch");
    }

    @Test
    public void tc004_loginFormVisible() {
        Assert.assertTrue(home.isUsernameVisible(), "username field missing");
        Assert.assertTrue(home.isPasswordVisible(), "password field missing");
        Assert.assertTrue(home.isLoginButtonVisible(), "login button missing");
    }

    @Test
    public void tc005_backButton() {
        driver.get("https://example.com/");
        driver.navigate().back();
        Assert.assertTrue(driver.getCurrentUrl().contains("saucedemo.com"));
    }

    @Test
    public void tc006_usernamePlaceholder() {
        String ph = home.getUsernamePlaceholder();
        Assert.assertTrue(ph != null && !ph.trim().isEmpty(), "username placeholder empty");
    }

    @Test
    public void tc007_passwordPlaceholder() {
        String ph = home.getPasswordPlaceholder();
        Assert.assertTrue(ph != null && !ph.trim().isEmpty(), "password placeholder empty");
    }

    @Test
    public void tc008_loginButtonEnabled() {
        Assert.assertTrue(home.isLoginButtonEnabled(), "login button should be enabled");
    }

    @Test
    public void tc009_copyRightOrFooter() {
        Assert.assertFalse(home.isFooterVisible(), "footer/login footer should be present");
    }

    @Test
    public void tc010_acceptedUsernames() {
        String txt = home.getAcceptedUsernamesText();
        Assert.assertTrue(txt.toLowerCase().contains("standard_user"), "accepted usernames list missing");
    }

    @Test
    public void tc011_passwordForAllUsers() {
        String txt = home.getPasswordInfoText();
        Assert.assertTrue(txt.toLowerCase().contains("secret_sauce"), "password info missing");
    }

    @Test
    public void tc012_formAlignmentCheck() {
        Assert.assertTrue(home.isUsernameVisible() && home.isPasswordVisible() && home.isLoginButtonVisible());
    }

    @Test
    public void tc013_homepageURL() {
        Assert.assertTrue(driver.getCurrentUrl().contains("saucedemo.com"));
    }

    @Test
    public void tc014_faviconDisplayed() {
        Assert.assertTrue(home.isFaviconPresent(), "favicon link not found");
    }

    @Test
    public void tc015_textReadability() {
        String logo = home.getTitle();
        String ph = home.getUsernamePlaceholder();
        Assert.assertTrue(logo != null && !logo.isEmpty() && ph != null && !ph.isEmpty(), "text not readable or missing");
    }
}
