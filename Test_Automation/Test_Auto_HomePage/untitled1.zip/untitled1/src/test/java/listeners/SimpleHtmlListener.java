package listeners;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

public class SimpleHtmlListener implements ITestListener {

    private StringBuilder html = new StringBuilder();
    private int passed = 0, failed = 0, skipped = 0;
    private String startTime;

    @Override
    public void onStart(ITestContext context) {
        startTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
        html.append("<!doctype html><html><head><meta charset='utf-8'><title>Simple Test Report</title>");
        html.append("<style>body{font-family:Arial} table{border-collapse:collapse;width:100%} th,td{border:1px solid #ddd;padding:8px} th{background:#333;color:#fff}</style>");
        html.append("</head><body>");
        html.append("<h2>Simple TestNG Report</h2>");
        html.append("<p>Start: ").append(startTime).append("</p>");
        html.append("<table><thead><tr><th>#</th><th>Test</th><th>Status</th><th>Message</th></tr></thead><tbody>");
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        passed++;
        appendRow(result, "PASS", "");
    }

    @Override
    public void onTestFailure(ITestResult result) {
        failed++;
        String msg = "";
        if (result.getThrowable() != null) {
            msg = result.getThrowable().toString();
        }
        appendRow(result, "FAIL", escapeHtml(msg));
    }

    @Override
    public void onTestSkipped(ITestResult result) {
        skipped++;
        String msg = (result.getThrowable() != null) ? result.getThrowable().toString() : "";
        appendRow(result, "SKIPPED", escapeHtml(msg));
    }

    private int counter = 0;
    private void appendRow(ITestResult result, String status, String msg) {
        counter++;
        String color = "black";
        if ("PASS".equals(status)) color = "green";
        if ("FAIL".equals(status)) color = "red";
        html.append("<tr>");
        html.append("<td>").append(counter).append("</td>");
        html.append("<td>").append(result.getMethod().getMethodName()).append("</td>");
        html.append("<td style='color:").append(color).append("'><b>").append(status).append("</b></td>");
        html.append("<td>").append(msg).append("</td>");
        html.append("</tr>");
    }

    @Override
    public void onFinish(ITestContext context) {
        html.append("</tbody></table>");
        html.append("<p>Summary: Passed=").append(passed).append(", Failed=").append(failed).append(", Skipped=").append(skipped).append("</p>");
        html.append("<p>End: ").append(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date())).append("</p>");
        html.append("</body></html>");

        try {
            File outDir = new File(System.getProperty("user.dir") + "/test-output");
            if (!outDir.exists()) outDir.mkdirs();
            String file = outDir + "/simple-report.html";
            try (PrintWriter pw = new PrintWriter(new FileWriter(file, false))) {
                pw.write(html.toString());
            }
            System.out.println("Simple HTML report generated: " + file);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private String escapeHtml(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<","&lt;").replace(">", "&gt;").replace("\n", "<br/>");
    }

    // unused interface methods
    @Override public void onTestFailedButWithinSuccessPercentage(ITestResult result) {}
    @Override public void onTestStart(ITestResult result) {}
}
